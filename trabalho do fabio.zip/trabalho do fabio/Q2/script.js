  let nota1=prompt('digite a primera nota:')
  let nota2=prompt('digite a segunda nota:')
  
  nota1=parseFloat(nota1);
  nota2=parseFloat(nota2);

  let media=((nota1+nota2)/2);

if(media==10){
    alert('APROVADO COM DISTIÇÃO!')
}if(media>=7){
    alert("APROVADO")
  }else{
    alert('REPROVADO')
  }

  
 
    
  
