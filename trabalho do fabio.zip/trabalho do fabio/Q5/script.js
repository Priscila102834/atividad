let num1 = prompt("Numero 1");
let num2 = prompt("Numero 2");

let a = num1;
let b = num2;
 let aux=num1
a=b
b=aux;
alert('NOVO VALOR DE A='+a)


alert('NOVO VALOR DE B='+b)