let num1 = prompt("DIGITE O 1° NUMERO");
let num2 = prompt("DIGITE O 2° NUMERO");
let num3 = prompt("DIGITE O 3° NUMERO");
let maior = num1,
  menor = num1;

if (num2 > maior) {
  maior = num2;
}
if (num3 > maior) {
  maior = num3;
}

if (num2 < menor) {
  menor = num2;
}
if (num3 < menor) {
  menor = num3;
}
alert("NUMERO MAIOR=" + maior);
alert("NUMERO MENOR=" + menor);
