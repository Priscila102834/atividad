  let letra= prompt('digite uma letra :')

  if(letra=='a' ||letra=='e' ||letra=='i' ||letra=='o' ||letra=='u'){
    alert('ESSA LETRA É UMA VOGAL!!')
  }else{
    alert('ESSA LETRA É UMA CONSOANTE!!')
  }